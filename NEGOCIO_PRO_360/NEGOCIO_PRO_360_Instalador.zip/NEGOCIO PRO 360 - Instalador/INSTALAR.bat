@echo off
title Instalador NEGOCIO PRO 360 ENTERPRISE
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar.ps1"
echo.
pause
