﻿# ============================================================================
#  Instalador de NEGOCIO PRO 360 ENTERPRISE
#  Crea la carpeta "NEGOCIO PRO 360" en el Escritorio con todo el sistema.
#  - No sobrescribe un sistema que ya tenga datos: deja la versión nueva aparte.
#  - Quita el bloqueo de Windows a los archivos descargados (para que las macros funcionen).
# ============================================================================
$ErrorActionPreference = 'Stop'
Write-Host ''
Write-Host '  NEGOCIO PRO 360 ENTERPRISE - Instalación' -ForegroundColor Cyan
Write-Host '  ----------------------------------------' -ForegroundColor Cyan
try {
    $origen = Join-Path $PSScriptRoot 'Archivos'
    if (-not (Test-Path -LiteralPath (Join-Path $origen 'NEGOCIO_PRO_360.xlsm'))) {
        throw 'No se encontró la carpeta Archivos. Primero extraiga TODO el ZIP (clic derecho > Extraer todo) y luego ejecute INSTALAR.bat desde la carpeta extraída.'
    }
    $escritorio = [Environment]::GetFolderPath('Desktop')
    $destino = Join-Path $escritorio 'NEGOCIO PRO 360'
    $carpetas = @($destino, (Join-Path $destino 'Informes'), (Join-Path $destino 'Respaldos'), (Join-Path $destino 'Documentacion'))
    foreach ($d in $carpetas) {
        if (-not (Test-Path -LiteralPath $d)) { New-Item -ItemType Directory -Path $d | Out-Null }
    }

    foreach ($f in @('NEGOCIO_PRO_360.xlsm', 'NEGOCIO_PRO_360.xlsx')) {
        $src = Join-Path $origen $f
        $dst = Join-Path $destino $f
        if (Test-Path -LiteralPath $dst) {
            $nuevo = Join-Path $destino ($f -replace '\.(xls[xm])$', '_NUEVA_VERSION.$1')
            Copy-Item -LiteralPath $src -Destination $nuevo -Force
            Write-Host ('  Ya existía {0}: se conservó con sus datos. La versión nueva quedó como {1}' -f $f, (Split-Path $nuevo -Leaf)) -ForegroundColor Yellow
        } else {
            Copy-Item -LiteralPath $src -Destination $dst
            Write-Host ('  Copiado: {0}' -f $f)
        }
    }
    foreach ($f in @('Manual_de_Usuario.pdf', 'Modulo_VBA.bas', 'Informe_de_pruebas.txt', 'Informe_ejemplo.pdf', 'Dashboard_ejemplo.pdf')) {
        $src = Join-Path $origen $f
        if (Test-Path -LiteralPath $src) {
            Copy-Item -LiteralPath $src -Destination (Join-Path (Join-Path $destino 'Documentacion') $f) -Force
            Write-Host ('  Copiado: Documentacion\{0}' -f $f)
        }
    }

    # Quitar la marca "descargado de internet" para que Excel no bloquee las macros
    Get-ChildItem -LiteralPath $destino -Recurse -File | ForEach-Object { Unblock-File -LiteralPath $_.FullName }

    Write-Host ''
    Write-Host ('  LISTO. Carpeta creada en: {0}' -f $destino) -ForegroundColor Green
    Write-Host '  Se abrirá la carpeta y el sistema. En Excel pulse "Habilitar contenido" si lo pide.'
    Start-Process -FilePath 'explorer.exe' -ArgumentList ('"{0}"' -f $destino)
    try {
        Start-Process -FilePath (Join-Path $destino 'NEGOCIO_PRO_360.xlsm')
    } catch {
        Write-Host '  No se pudo abrir Excel automáticamente. Abra NEGOCIO_PRO_360.xlsm desde la carpeta.' -ForegroundColor Yellow
    }
} catch {
    Write-Host ''
    Write-Host ('  ERROR: {0}' -f $_.Exception.Message) -ForegroundColor Red
    exit 1
}
